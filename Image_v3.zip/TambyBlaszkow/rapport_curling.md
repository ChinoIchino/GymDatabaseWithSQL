# Mène de curling en Three.js

**Auteurs :** TAMBY Sébastien & BLASZKOW Kamil  

Ce projet modélise une mène de curling avec :
- pierres réalisées par surfaces de révolution ;
- deux types de trajectoires (rectiligne et courbe) ;
- chocs vraisemblables ;
- score calculé selon la position des pierres dans la maison ;
- balais modélisés avec des primitives et animés lorsqu'une pierre est jouée.

Le reste du rapport (explication des choix techniques, schémas, difficultés) peut être complété à partir de ce squelette.
