// Calcul et affichage du score pour une mène de curling.

var HOUSE_RADIUS = 1.8;

function computeScoreForStones(stones, houseCenter) {
    var inside = [];

    for (var i = 0; i < stones.length; i++) {
        var s = stones[i];
        if (!s.userData || !s.userData.team) continue;

        var dx = s.position.x - houseCenter.x;
        var dz = s.position.z - houseCenter.z;
        var distSq = dx * dx + dz * dz;
        if (distSq <= HOUSE_RADIUS * HOUSE_RADIUS) {
            inside.push({
                team: s.userData.team,
                distSq: distSq
            });
        }
    }

    if (inside.length === 0) {
        return { rouge: 0, bleu: 0 };
    }

    inside.sort(function(a, b) { return a.distSq - b.distSq; });

    var bestTeam = inside[0].team;
    var scoreRouge = 0;
    var scoreBleu = 0;

    for (var k = 0; k < inside.length; k++) {
        if (inside[k].team !== bestTeam) break;
        if (bestTeam === "rouge") scoreRouge++;
        else if (bestTeam === "bleu") scoreBleu++;
    }

    return { rouge: scoreRouge, bleu: scoreBleu };
}

function updateScoreDisplay(scores, currentThrow, maxThrows) {
    var scoreRougeElem = document.getElementById("score-rouge");
    var scoreBleuElem = document.getElementById("score-bleu");
    var infoLancerElem = document.getElementById("info-lancer");
    var infoLeaderElem = document.getElementById("info-leader");

    if (!scoreRougeElem || !scoreBleuElem) return;

    scoreRougeElem.textContent = scores.rouge;
    scoreBleuElem.textContent = scores.bleu;

    infoLancerElem.textContent = "Lancer n° " + currentThrow + " / " + maxThrows;

    var leaderText = "Égalité pour l’instant.";
    var leaderColor = "#333333";

    if (scores.rouge > scores.bleu) {
        leaderText = "L’équipe ROUGE mène.";
        leaderColor = "#d32f2f";
    } else if (scores.bleu > scores.rouge) {
        leaderText = "L’équipe BLEUE mène.";
        leaderColor = "#1976d2";
    } else if (scores.rouge === 0 && scores.bleu === 0) {
        leaderText = "Aucune pierre suffisamment proche du centre.";
    }

    infoLeaderElem.textContent = leaderText;
    infoLeaderElem.style.color = leaderColor;
}
