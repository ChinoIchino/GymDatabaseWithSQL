// Trajectoires non rectilignes basées sur des courbes de Bézier (plan XZ).

var Trajectoires = {};

Trajectoires.createBezierPath = function(startX, startZ, params) {
    var start = new THREE.Vector2(startX, startZ);
    var p1 = new THREE.Vector2(params.courbureDepart, -3.5);
    var p2 = new THREE.Vector2(params.courbureMilieu, -1.5);
    var p3 = new THREE.Vector2(params.offsetFinal, 0.0);
    var p4 = new THREE.Vector2(params.offsetFinal, 1.2);

    var c1 = p1.clone();
    var curve1 = new THREE.QuadraticBezierCurve(start, c1, p2);

    var dir12 = new THREE.Vector2().subVectors(p2, c1).normalize();
    var c2 = p2.clone().add(dir12.clone().multiplyScalar(1.0));
    var mid23 = new THREE.Vector2(
        (p2.x + p3.x) * 0.5,
        (p2.y + p3.y) * 0.5
    );
    var c3 = mid23.clone();
    var curve2 = new THREE.CubicBezierCurve(p2, c2, c3, p3);

    var dir23 = new THREE.Vector2().subVectors(p3, c3).normalize();
    var c4 = p3.clone().add(dir23.clone().multiplyScalar(0.8));
    var c5 = new THREE.Vector2(p4.x, p4.y + 0.8);
    var curve3 = new THREE.CubicBezierCurve(p3, c4, c5, p4);

    var curves = [curve1, curve2, curve3];

    return {
        curves: curves,
        getPoint: function(t) {
            var n = this.curves.length;
            var scaledT = t * n;
            var index = Math.floor(scaledT);
            if (index >= n) index = n - 1;
            var localT = scaledT - index;
            return this.curves[index].getPoint(localT);
        },
        getPoints: function(steps) {
            var pts = [];
            for (var i = 0; i <= steps; i++) {
                var t = i / steps;
                pts.push(this.getPoint(t));
            }
            return pts;
        }
    };
};
