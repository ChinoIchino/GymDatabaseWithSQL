// Gestion simplifiée des collisions entre pierres, avec un comportement "naturel".
// Chaque pierre est modélisée comme un disque 2D dans le plan XZ.

function handleStoneCollisions(stones) {
    var n = stones.length;
    for (var i = 0; i < n; i++) {
        for (var j = i + 1; j < n; j++) {
            var s1 = stones[i];
            var s2 = stones[j];

            if (!s1.userData || !s2.userData) continue;

            var pos1 = s1.position;
            var pos2 = s2.position;

            var dx = pos2.x - pos1.x;
            var dz = pos2.z - pos1.z;
            var distSq = dx * dx + dz * dz;
            var minDist = STONE_RADIUS * 2.0;

            if (distSq > 0 && distSq < minDist * minDist) {
                resolveStoneCollision(s1, s2);

                var dist = Math.sqrt(distSq) || minDist;
                var overlap = (minDist - dist) * 0.5;
                var nx = dx / dist;
                var nz = dz / dist;
                s1.position.x -= nx * overlap;
                s1.position.z -= nz * overlap;
                s2.position.x += nx * overlap;
                s2.position.z += nz * overlap;
            }
        }
    }
}

function resolveStoneCollision(s1, s2) {
    var v1 = s1.userData.velocity.clone();
    var v2 = s2.userData.velocity.clone();

    var dx = s2.position.x - s1.position.x;
    var dz = s2.position.z - s1.position.z;
    var dist = Math.sqrt(dx * dx + dz * dz);
    if (dist === 0) return;

    var nx = dx / dist;
    var nz = dz / dist;

    var rvx = v1.x - v2.x;
    var rvz = v1.z - v2.z;
    var velAlongNormal = rvx * nx + rvz * nz;

    if (velAlongNormal <= 0.01) {
        return;
    }

    var e = 0.45;

    var j = -(1 + e) * velAlongNormal / 2.0;
    j *= 0.75;

    var impulseX = j * nx;
    var impulseZ = j * nz;

    v1.x += impulseX;
    v1.z += impulseZ;
    v2.x -= impulseX;
    v2.z -= impulseZ;

    v1.multiplyScalar(0.92);
    v2.multiplyScalar(0.92);

    s1.userData.velocity.copy(v1);
    s2.userData.velocity.copy(v2);

    s1.userData.moving = true;
    s2.userData.moving = true;
    s1.userData.mode = "free";
    s2.userData.mode = "free";
}
