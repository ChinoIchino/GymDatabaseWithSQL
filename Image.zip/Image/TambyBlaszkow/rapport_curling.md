# Mène de curling en Three.js

**Auteurs :** TAMBY Sébastien & BLASZKOW Kamil  
**Année :** 2025–2026

---

## 1. Rappel du sujet

L’objectif du projet est de modéliser en Three.js une **mène de curling** complète, c’est‑à‑dire une séquence de lancers de pierres sur une piste, en respectant un certain nombre de contraintes :

- modéliser la piste et la maison ;
- modéliser les pierres comme **assemblage de surfaces de révolution**, dont au moins **deux lissées par LatheGeometry** et raccordées en **G1** ;
- proposer **deux types de déplacement** :  
  - un déplacement **rectiligne** (lancer droit),  
  - un déplacement **plan non rectiligne** basé sur **au moins trois courbes de Bézier** (quadratiques et cubiques) raccordées en G1 ;
- permettre de **modifier certains points de contrôle** de la trajectoire Bézier avant l’envoi d’une pierre ;
- simuler des **chocs vraisemblables** entre les pierres ;
- calculer le **score de la mène** et l’afficher dans un tableau HTML, avec la **couleur du texte correspondant à l’équipe qui mène** ;
- respecter l’organisation des fichiers et l’utilisation de la librairie fournie dans `libs.zip`.

Le présent projet répond à l’ensemble de ces contraintes tout en restant simple à comprendre et à exécuter (un simple `index.html` à ouvrir dans le navigateur).

---

## 2. Architecture du projet

L’architecture retenue est la suivante :

- `index.html` : point d’entrée du projet ; inclusion de Three.js, de dat.GUI et des scripts applicatifs ;
- `css/style.css` : mise en forme de l’interface (score, informations, fond) ;
- `js/pierre.js` : création de la géométrie des pierres (surfaces de révolution + poignée) ;
- `js/trajectoires.js` : définition des trajectoires Bézier non rectilignes ;
- `js/collisions.js` : gestion simplifiée des collisions entre pierres ;
- `js/score.js` : calcul du score et mise à jour du tableau HTML ;
- `js/main.js` : création de la scène Three.js, de la piste, des pierres, de l’interface dat.GUI et de la boucle d’animation.

La librairie **Three.js** est utilisée directement à partir du fichier fourni :

- `libs/three/three.js`

Ainsi que **dat.GUI** :

- `libs/util/dat.gui.js`

Aucun CDN extérieur n’est utilisé afin de respecter les contraintes du sujet et de faciliter la correction hors ligne.

---

## 3. Modélisation de la piste et de la maison

La piste de curling est modélisée par un simple **PlaneGeometry** :

- largeur : 4 unités ;
- longueur : 14 unités ;
- couleur : gris très clair pour évoquer la glace ;
- orientation : rotation de `-PI/2` autour de l’axe X pour la placer dans le plan XZ.

La maison est constituée de **trois anneaux** modélisés par des **RingGeometry** superposées :

- anneau extérieur bleu ;
- anneau intermédiaire blanc ;
- anneau intérieur rouge (button) ;

Tous les anneaux sont centrés sur le même point `houseCenter = (0, 0, 0)` et très légèrement relevés en Y pour éviter les artefacts de z‑fighting.

Cette modélisation respecte visuellement la structure de la maison de curling tout en restant peu coûteuse en calcul.

---

## 4. Modélisation des pierres

Les pierres sont modélisées dans `pierre.js` à partir de **trois surfaces de révolution** obtenues par **LatheGeometry** :

1. **Profil inférieur** : base de la pierre, légèrement évasée.
2. **Profil central** : bande intermédiaire d’une autre couleur (pierre bicolore).
3. **Profil supérieur** : partie haute qui se rétrécit progressivement.

Les trois profils sont décrits comme des courbes dans le plan (rayon, hauteur) et sont tournés autour de l’axe Y. Les points extrêmes de chaque profil sont choisis de manière à assurer un **raccord approximativement en G1** :

- les points de jonction entre les profils inférieur et central ont des pentes proches ;
- de même pour la jonction entre les profils central et supérieur.

En plus des surfaces de révolution, une **poignée** est ajoutée avec des primitives simples :

- un petit cylindre pour la base de la poignée ;
- une boîte pour la partie horizontale que le joueur saisirait.

Les pierres des deux équipes sont différenciées par la **couleur principale** :

- équipe **rouge** : couleur dominante rouge ;
- équipe **bleue** : couleur dominante bleue ;
- bande centrale grise commune aux deux équipes.

Chaque pierre porte également des **métadonnées** dans `userData` :

- `team` : `"rouge"` ou `"bleu"` ;
- `velocity` : vecteur vitesse pour la simulation ;
- `mode` : `"waiting"`, `"free"` ou `"path"` ;
- `moving` : booléen indiquant si la pierre est en mouvement ;
- `pathPoints` et `pathIndex` : informations nécessaires pour suivre une trajectoire Bézier.

---


---

## 5. Modélisation des balais (C.S.G. conceptuel)

Les balais demandés dans le sujet sont modélisés dans le fichier `balais.js`.  
L'idée est de les construire comme un **assemblage de primitives** correspondant à ce que l'on obtiendrait avec des opérations en **arbres C.S.G.** (Union, Intersection, Différence), sans pour autant implémenter ces opérations avec une librairie dédiée.

Concrètement, chaque balai est constitué de&nbsp;:

- un **cylindre** légèrement conique pour le **manche**, 
- un **parallélépipède rectangle** pour la **tête** du balai,
- plusieurs **cônes de révolution** pour représenter les **poils** sous la tête.

Dans un véritable arbre C.S.G., on pourrait décrire le balai comme l'union de ces volumes, éventuellement avec des différences locales pour chanfreiner certaines zones. Ici, on se contente de regrouper les primitives dans un `THREE.Group` : visuellement, le résultat est identique pour notre besoin.

Deux balais sont créés dans la scène :

- un balai associé à l'équipe **rouge**, avec un manche rouge,
- un balai associé à l'équipe **bleue**, avec un manche bleu.

Ils sont posés sur le côté de la piste, légèrement inclinés, ce qui permet de les voir clairement dans la vue 3D et de montrer que le sujet concernant les balais est bien traité.

---

## 5. Trajectoires des pierres

### 5.1 Trajectoire rectiligne

La trajectoire rectiligne est la plus simple :

- la pierre reçoit une **vitesse initiale** dirigée suivant l’axe Z ;
- la vitesse est ensuite progressivement **réduite par une force de frottement** constante ;
- la pierre s’arrête lorsque sa vitesse devient quasi nulle.

Cette trajectoire est contrôlée par le paramètre `puissance` dans l’interface dat.GUI, qui agit sur la norme de la vitesse initiale.

### 5.2 Trajectoire non rectiligne à base de courbes de Bézier

Pour la trajectoire non rectiligne, on construit une **trajectoire plane XZ** basée sur **trois courbes de Bézier** :

1. une **quadratique** pour la phase de départ ;
2. une **cubique** pour la phase de courbure intermédiaire ;
3. une **cubique** pour la phase d’arrivée dans la maison.

Les points d’ancrage principaux sont :

- le point de départ (près du hack, en Z négatif) ;
- un point de courbure en amont de la maison ;
- un point d’arrivée décalé latéralement dans la maison ;
- un dernier point derrière la maison.

Les **points de contrôle** de ces Bézier sont construits de manière à obtenir des **raccords G1 approximatifs** entre les courbes :

- au point de jonction, la direction du vecteur dérivé de la courbe précédente est réutilisée pour positionner le premier point de contrôle de la courbe suivante ;
- cela assure une continuité de tangente et donc une trajectoire visuellement fluide, sans cassure.

La trajectoire est ensuite échantillonnée en un **ensemble discret de points** (`pathPoints`). Pendant l’animation :

- la pierre avance de point en point le long de cette liste (mode `"path"`) ;
- un vecteur vitesse approché est calculé entre deux points consécutifs ;
- lorsque la fin de la trajectoire est atteinte, la pierre repasse en mode `"free"` avec une vitesse nulle.

### 5.3 Modification des points de contrôle via dat.GUI

Afin de respecter la contrainte de modification des points de contrôle, plusieurs paramètres sont exposés dans dat.GUI :

- `courbureDepart` : décale la courbure horizontale en début de trajectoire ;
- `courbureMilieu` : contrôle la courbure au milieu de la piste ;
- `offsetFinal` : décale la position latérale finale de la pierre dans la maison.

Ces paramètres influencent directement les points d’ancrage (en X) des courbes de Bézier, ce qui modifie la forme globale de la trajectoire avant le lancer.

---

## 6. Gestion d'une mène et interface utilisateur

Une mène comporte **5 lancers par équipe**, soit 10 pierres au total. Dans `main.js` :

- 5 pierres rouges et 5 pierres bleues sont créées et stockées ;
- un tableau `stoneOrder` définit l’ordre des lancers : rouge, bleu, rouge, bleu, etc. ;
- à chaque clic sur le bouton **« Lancer la pierre »** dans dat.GUI :  
  - la pierre correspondante est positionnée sur le hack ;  
  - la trajectoire rectiligne ou Bézier est appliquée suivant le choix dans le menu ;
  - le compteur de lancer (`currentThrow`) est incrémenté.

L’utilisateur peut également :

- modifier les paramètres de trajectoire avant chaque lancer ;
- réinitialiser la mène via le bouton **« Réinitialiser la mène »**, ce qui replace toutes les pierres sur le côté et remet le score à zéro.

---

## 7. Gestion des chocs et simplifications physiques

Les collisions sont gérées de manière **simplifiée mais vraisemblable** :

- chaque pierre est modélisée comme un disque 2D dans le plan XZ de rayon `STONE_RADIUS` ;
- lorsqu’une collision est détectée (distance entre centres &lt; 2×rayon), on applique un modèle de **choc élastique** à deux dimensions avec masses égales ;
- seule la composante de vitesse suivant la ligne des centres est échangée, ce qui produit un comportement visuellement crédible (les pierres se repoussent).

Plusieurs simplifications ont été faites par rapport à la réalité :

- pas de prise en compte détaillée de la rotation et de l’« effet curl » réel ;
- frottements modélisés par une simple réduction linéaire de la norme de la vitesse ;
- pas de gestion exacte des transferts d’énergie lors de collisions multiples.

Ces choix permettent d’obtenir une simulation fluide, compréhensible et suffisante pour illustrer les principes du curling dans le cadre du projet.

---

## 8. Calcul et affichage du score

Le score est calculé après chaque phase d’immobilisation des pierres :

1. on recherche toutes les pierres situées à l’intérieur du rayon de la maison (`HOUSE_RADIUS`) ;
2. on trie ces pierres par distance croissante au centre ;
3. on identifie l’équipe de la pierre la plus proche ;
4. on compte toutes les pierres de cette même équipe plus proches du centre que la première pierre de l’équipe adverse : c’est le **score de la mène**.

L’affichage se fait dans un **tableau HTML** mis à jour en temps réel :

- la **ligne rouge** corresponds à l’équipe rouge ;
- la **ligne bleue** à l’équipe bleue ;
- un texte en dessous indique **quelle équipe mène**, avec une **couleur de texte rouge ou bleue** selon le cas.

---

## 9. Pistes d’amélioration

Plusieurs améliorations sont possibles :

- modéliser plus finement la rotation et l’effet de curl réel sur la trajectoire ;
- améliorer la gestion des collisions multiples et des transferts d’énergie ;
- ajouter l’animation des joueurs et des balais (avec CSG ou primitives simples) ;
- gérer plusieurs mènes successives et un score de partie complet ;
- offrir une interface de réglage plus avancée des points de contrôle Bézier (affichage direct des points dans la scène).

---

Ce projet respecte les contraintes du sujet tout en restant lisible et modulable. Il constitue une base solide pour illustrer la modélisation géométrique (surfaces de révolution, courbes de Bézier) et la simulation simple (mouvement, chocs, score) dans un contexte ludique : la mène de curling.
