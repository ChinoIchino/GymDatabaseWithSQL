// Modélisation d'une pierre de curling à partir de plusieurs surfaces de révolution
// On utilise Three.js LatheGeometry pour respecter le sujet.

// Rayon et hauteur approximatifs de la pierre (unités arbitraires)
var STONE_RADIUS = 0.19;
var STONE_HEIGHT = 0.12;

function createStone(mainColor, middleColor) {
    var group = new THREE.Group();

    // ----------- Profil 1 : partie inférieure (Lathe lisse) -----------
    var pointsBase = [];
    pointsBase.push(new THREE.Vector2(0.00, 0.00));
    pointsBase.push(new THREE.Vector2(0.16, 0.00));
    pointsBase.push(new THREE.Vector2(0.19, 0.015));
    pointsBase.push(new THREE.Vector2(0.20, 0.03)); // raccord avec profil 2 (G1 approx)

    var geoBase = new THREE.LatheGeometry(pointsBase, 64);
    var matBase = new THREE.MeshPhongMaterial({ color: mainColor, shininess: 80 });
    var meshBase = new THREE.Mesh(geoBase, matBase);
    meshBase.castShadow = true;
    meshBase.receiveShadow = true;
    group.add(meshBase);

    // ----------- Profil 2 : bande centrale (Lathe lisse, couleur différente) -----------
    var pointsMiddle = [];
    pointsMiddle.push(new THREE.Vector2(0.20, 0.03));   // raccord G1 approx avec profil 1
    pointsMiddle.push(new THREE.Vector2(0.205, 0.06));
    pointsMiddle.push(new THREE.Vector2(0.19, 0.09));

    var geoMiddle = new THREE.LatheGeometry(pointsMiddle, 64);
    var matMiddle = new THREE.MeshPhongMaterial({ color: middleColor, shininess: 40 });
    var meshMiddle = new THREE.Mesh(geoMiddle, matMiddle);
    meshMiddle.castShadow = true;
    meshMiddle.receiveShadow = true;
    group.add(meshMiddle);

    // ----------- Profil 3 : partie supérieure (Lathe plus petite) -----------
    var pointsTop = [];
    pointsTop.push(new THREE.Vector2(0.19, 0.09));
    pointsTop.push(new THREE.Vector2(0.16, 0.11));
    pointsTop.push(new THREE.Vector2(0.10, 0.12));

    var geoTop = new THREE.LatheGeometry(pointsTop, 64);
    var matTop = new THREE.MeshPhongMaterial({ color: mainColor, shininess: 80 });
    var meshTop = new THREE.Mesh(geoTop, matTop);
    meshTop.castShadow = true;
    meshTop.receiveShadow = true;
    group.add(meshTop);

    // ----------- Poignée : primitives simples -----------
    var handleHeight = 0.05;
    var handleRadius = 0.04;

    var geoHandleBase = new THREE.CylinderGeometry(handleRadius, handleRadius, handleHeight * 0.5, 16);
    var matHandle = new THREE.MeshPhongMaterial({ color: middleColor, shininess: 60 });
    var meshHandleBase = new THREE.Mesh(geoHandleBase, matHandle);
    meshHandleBase.position.y = 0.12 + handleHeight * 0.25;
    meshHandleBase.castShadow = true;
    meshHandleBase.receiveShadow = true;
    group.add(meshHandleBase);

    var geoHandleBar = new THREE.BoxGeometry(handleRadius * 3, handleHeight * 0.3, handleRadius * 1.2);
    var meshHandleBar = new THREE.Mesh(geoHandleBar, matHandle);
    meshHandleBar.position.y = 0.12 + handleHeight * 0.65;
    meshHandleBar.castShadow = true;
    meshHandleBar.receiveShadow = true;
    group.add(meshHandleBar);

    // Centrage approximatif
    group.position.y = 0.0;

    // Métadonnées utilisées par la simulation
    group.userData.velocity = new THREE.Vector3(0, 0, 0);
    group.userData.moving = false;
    group.userData.mode = "waiting"; // "waiting", "free", "path"
    group.userData.pathPoints = null;
    group.userData.pathIndex = 0;
    group.userData.inGame = false;   // devient vrai après le premier lancer

    return group;
}
