// Gestion simplifiée des collisions entre pierres, avec un comportement plus "naturel".
// Chaque pierre est modélisée comme un disque 2D dans le plan XZ.

function handleStoneCollisions(stones) {
    var n = stones.length;
    for (var i = 0; i < n; i++) {
        for (var j = i + 1; j < n; j++) {
            var s1 = stones[i];
            var s2 = stones[j];

            if (!s1.userData || !s2.userData) continue;

            var pos1 = s1.position;
            var pos2 = s2.position;

            var dx = pos2.x - pos1.x;
            var dz = pos2.z - pos1.z;
            var distSq = dx * dx + dz * dz;
            var minDist = STONE_RADIUS * 2.0;

            if (distSq > 0 && distSq < minDist * minDist) {
                // Résolution du choc
                resolveStoneCollision(s1, s2);

                // Légère séparation pour éviter les inter-pénétrations persistantes
                var dist = Math.sqrt(distSq) || minDist;
                var overlap = (minDist - dist) * 0.5;
                var nx = dx / dist;
                var nz = dz / dist;
                s1.position.x -= nx * overlap;
                s1.position.z -= nz * overlap;
                s2.position.x += nx * overlap;
                s2.position.z += nz * overlap;
            }
        }
    }
}

function resolveStoneCollision(s1, s2) {
    // Copie des vitesses actuelles
    var v1 = s1.userData.velocity.clone();
    var v2 = s2.userData.velocity.clone();

    // Vecteur normal de la collision (dans le plan XZ)
    var dx = s2.position.x - s1.position.x;
    var dz = s2.position.z - s1.position.z;
    var dist = Math.sqrt(dx * dx + dz * dz);
    if (dist === 0) return;

    var nx = dx / dist;
    var nz = dz / dist;

    // Vitesse relative projetée sur la normale
    var rvx = v1.x - v2.x;
    var rvz = v1.z - v2.z;
    var velAlongNormal = rvx * nx + rvz * nz;

    // Si les pierres s'éloignent déjà ou se déplacent à peine l'une vers l'autre, on ignore
    if (velAlongNormal <= 0.01) {
        return;
    }

    // Coefficient de restitution (0 = choc mou, 1 = parfaitement élastique).
    // On prend une valeur assez basse pour un effet plus doux.
    var e = 0.45;

    // Masses égales (m1 = m2 = 1) -> dénominateur = 1/m1 + 1/m2 = 2
    var j = -(1 + e) * velAlongNormal / 2.0;

    // On diminue encore un peu l'impulsion pour éviter les chocs trop violents.
    j *= 0.75;

    // Impulsion totale
    var impulseX = j * nx;
    var impulseZ = j * nz;

    // Application de l'impulsion (m = 1)
    v1.x += impulseX;
    v1.z += impulseZ;
    v2.x -= impulseX;
    v2.z -= impulseZ;

    // Légère perte d'énergie globale pour atténuer le rebond
    v1.multiplyScalar(0.92);
    v2.multiplyScalar(0.92);

    s1.userData.velocity.copy(v1);
    s2.userData.velocity.copy(v2);

    // Après collision, les deux pierres sont en mouvement libre
    s1.userData.moving = true;
    s2.userData.moving = true;
    s1.userData.mode = "free";
    s2.userData.mode = "free";
}
