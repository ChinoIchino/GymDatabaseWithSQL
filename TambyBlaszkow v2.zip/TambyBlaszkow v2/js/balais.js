// Modélisation des balais de curling : cylindre (manche), pavé (tête), cônes (poils).

function createBroom(handleColor, headColor) {
    var group = new THREE.Group();

    // Manche : cylindre légèrement conique
    var handleRadiusTop = 0.03;
    var handleRadiusBottom = 0.035;
    var handleHeight = 1.4;
    var geoHandle = new THREE.CylinderGeometry(handleRadiusTop, handleRadiusBottom, handleHeight, 16);
    var matHandle = new THREE.MeshPhongMaterial({ color: handleColor, shininess: 60 });
    var meshHandle = new THREE.Mesh(geoHandle, matHandle);
    meshHandle.castShadow = true;
    meshHandle.receiveShadow = true;
    meshHandle.position.y = handleHeight * 0.5;
    group.add(meshHandle);

    // Tête du balai : parallélépipède rectangle
    var headWidth = 0.30;
    var headHeight = 0.04;
    var headDepth = 0.12;
    var geoHead = new THREE.BoxGeometry(headWidth, headHeight, headDepth);
    var matHead = new THREE.MeshPhongMaterial({ color: headColor, shininess: 30 });
    var meshHead = new THREE.Mesh(geoHead, matHead);
    meshHead.castShadow = true;
    meshHead.receiveShadow = true;
    meshHead.position.y = 0.02;
    group.add(meshHead);

    // Poils : plusieurs cônes sous la tête
    var bristleRadius = 0.035;
    var bristleHeight = 0.08;
    var geoBristle = new THREE.ConeGeometry(bristleRadius, bristleHeight, 12);
    var matBristle = new THREE.MeshPhongMaterial({ color: headColor, shininess: 20 });

    var offsets = [-0.10, 0.0, 0.10];
    for (var i = 0; i < offsets.length; i++) {
        var bristle = new THREE.Mesh(geoBristle, matBristle);
        bristle.castShadow = true;
        bristle.receiveShadow = true;
        bristle.rotation.x = Math.PI;
        bristle.position.set(offsets[i], -bristleHeight * 0.5, 0.0);
        group.add(bristle);
    }

    // Tilt de base vers l'avant
    group.userData.baseTiltX = -0.18;
    group.rotation.x = group.userData.baseTiltX;
    group.rotation.z = -0.35;

    // Dernière direction connue de la pierre associée
    group.userData.lastDir = new THREE.Vector3(0, 0, 1);

    return group;
}
