// Script principal : scène, pierres, balais, interface et animation.

var scene, camera, renderer;
var clock = new THREE.Clock();

var stones = [];
var stoneOrder = [];
var currentThrow = 0;
var maxThrows = 10;

var gui, guiParams, guiBezierFolder;

var houseCenter = new THREE.Vector3(0, 0.001, 0);
var iceWidth = 4.0;
var iceLength = 14.0;

var anyStoneMoving = false;

// Balais
var broomRed = null;
var broomBlue = null;
var activeBroom = null;
var activeBroomStone = null;
var broomPhase = 0;

function setBroomToHome(broom) {
    if (!broom) return;
    var hp = broom.userData.homePos;
    if (hp) {
        broom.position.copy(hp);
    }
    if (broom.userData.baseTiltX !== undefined) {
        broom.rotation.x = broom.userData.baseTiltX;
    }
    if (broom.userData.homeRotY !== undefined) {
        broom.rotation.y = broom.userData.homeRotY;
    }
}


function startBroomReturn(broom) {
    if (!broom) return;
    broom.userData.returning = true;
    broom.userData.returnT = 0.0;
    broom.userData.returnDuration = 0.6;
    broom.userData.returnStartPos = broom.position.clone();
    broom.userData.returnStartRotY = broom.rotation.y;
}

function createBrooms() {
    broomRed = createBroom(0xd32f2f, 0x757575);
    broomBlue = createBroom(0x1976d2, 0x757575);

    broomRed.userData.homePos = new THREE.Vector3(-2.1, 0.02, -2.0);
    broomRed.userData.homeRotY = Math.PI * 0.15;
    broomBlue.userData.homePos = new THREE.Vector3(2.1, 0.02, -1.2);
    broomBlue.userData.homeRotY = -Math.PI * 0.12;

    setBroomToHome(broomRed);
    setBroomToHome(broomBlue);

    scene.add(broomRed);
    scene.add(broomBlue);
}

init();
animate();

function init() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0xb3e5fc);

    var aspect = window.innerWidth / window.innerHeight;
    camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 100);
    camera.position.set(0, 5.2, 8.5);
    camera.lookAt(new THREE.Vector3(0, 0, 0));

    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    document.body.appendChild(renderer.domElement);

    var hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 0.6);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);

    var dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(3, 10, 5);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    scene.add(dirLight);

    createIceAndHouse();
    createStones();
    createBrooms();
    setupGUI();

    window.addEventListener("resize", onWindowResize, false);
}

function createIceAndHouse() {
    var iceGeo = new THREE.PlaneGeometry(iceWidth, iceLength);
    var iceMat = new THREE.MeshPhongMaterial({
        color: 0xf5f5f5,
        shininess: 80
    });
    var iceMesh = new THREE.Mesh(iceGeo, iceMat);
    iceMesh.rotation.x = -Math.PI / 2;
    iceMesh.receiveShadow = true;
    scene.add(iceMesh);

    var houseY = 0.002;

    var outerRingGeo = new THREE.RingGeometry(1.2, 1.8, 64);
    var outerRingMat = new THREE.MeshPhongMaterial({
        color: 0x1565c0,
        side: THREE.DoubleSide
    });
    var outerRing = new THREE.Mesh(outerRingGeo, outerRingMat);
    outerRing.rotation.x = -Math.PI / 2;
    outerRing.position.set(houseCenter.x, houseY, houseCenter.z);
    outerRing.receiveShadow = true;
    scene.add(outerRing);

    var middleRingGeo = new THREE.RingGeometry(0.6, 1.2, 64);
    var middleRingMat = new THREE.MeshPhongMaterial({
        color: 0xffffff,
        side: THREE.DoubleSide
    });
    var middleRing = new THREE.Mesh(middleRingGeo, middleRingMat);
    middleRing.rotation.x = -Math.PI / 2;
    middleRing.position.copy(outerRing.position);
    middleRing.receiveShadow = true;
    scene.add(middleRing);

    var innerRingGeo = new THREE.RingGeometry(0.0, 0.6, 64);
    var innerRingMat = new THREE.MeshPhongMaterial({
        color: 0xd32f2f,
        side: THREE.DoubleSide
    });
    var innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
    innerRing.rotation.x = -Math.PI / 2;
    innerRing.position.copy(outerRing.position);
    innerRing.receiveShadow = true;
    scene.add(innerRing);

    var hackGeo = new THREE.BoxGeometry(0.4, 0.02, 0.2);
    var hackMat = new THREE.MeshPhongMaterial({ color: 0x888888 });
    var hackMesh = new THREE.Mesh(hackGeo, hackMat);
    hackMesh.position.set(0, 0.01, -6.5);
    hackMesh.receiveShadow = true;
    scene.add(hackMesh);
}

function createStones() {
    var redColor = 0xd32f2f;
    var blueColor = 0x1976d2;
    var middleColor = 0xbdbdbd;

    var redTeam = [];
    var blueTeam = [];

    for (var i = 0; i < 5; i++) {
        var stoneRed = createStone(redColor, middleColor);
        stoneRed.position.set(-1.5, 0.0, -5.6 - i * 0.35);
        stoneRed.userData.team = "rouge";
        scene.add(stoneRed);
        stones.push(stoneRed);
        redTeam.push(stoneRed);

        var stoneBlue = createStone(blueColor, middleColor);
        stoneBlue.position.set(1.5, 0.0, -5.6 - i * 0.35);
        stoneBlue.userData.team = "bleu";
        scene.add(stoneBlue);
        stones.push(stoneBlue);
        blueTeam.push(stoneBlue);
    }

    for (var k = 0; k < 5; k++) {
        stoneOrder.push(redTeam[k]);
        stoneOrder.push(blueTeam[k]);
    }
}

function setupGUI() {
    guiParams = {
        typeTrajectoire: "Rectiligne",
        puissance: 4.0,
        courbureDepart: 0.3,
        courbureMilieu: 0.0,
        offsetFinal: 0.3,
        lancer: function() {
            lancerPierreCourante();
        },
        reset: function() {
            resetScene();
        }
    };

    gui = new dat.GUI();
    gui.width = 300;

    gui.add(guiParams, "typeTrajectoire", ["Rectiligne", "Courbe Bézier"])
        .name("Type de trajectoire");

    gui.add(guiParams, "puissance", 1.0, 10.0, 0.1)
        .name("Puissance du lancer");

    guiBezierFolder = gui.addFolder("Paramètres Bézier");
    guiBezierFolder.add(guiParams, "courbureDepart", -1.5, 1.5, 0.05)
        .name("Courbure départ (X)");
    guiBezierFolder.add(guiParams, "courbureMilieu", -1.5, 1.5, 0.05)
        .name("Courbure milieu (X)");
    guiBezierFolder.add(guiParams, "offsetFinal", -2.0, 2.0, 0.05)
        .name("Offset final (X)");
    guiBezierFolder.open();

    gui.add(guiParams, "lancer").name("Lancer la pierre");
    gui.add(guiParams, "reset").name("Réinitialiser la mène");
}

function lancerPierreCourante() {
    if (currentThrow >= maxThrows) {
        return;
    }
    if (isAnyStoneMoving()) {
        return;
    }

    var stone = stoneOrder[currentThrow];
    if (!stone) return;

    var team = stone.userData.team || "rouge";
    var startX = team === "rouge" ? -0.3 : 0.3;
    var startZ = -6.5;

    stone.position.set(startX, 0.0, startZ);
    stone.userData.inGame = true;
    stone.userData.pathPoints = null;
    stone.userData.pathIndex = 0;

    if (guiParams.typeTrajectoire === "Rectiligne") {
        stone.userData.mode = "free";
        var baseSpeed = 2.0 + guiParams.puissance * 0.6;
        stone.userData.velocity.set(0, 0, baseSpeed);
        stone.userData.moving = true;
    } else {
        var path = Trajectoires.createBezierPath(startX, startZ, guiParams);
        var pathPoints2D = path.getPoints(220);
        var pathPoints3D = [];
        for (var i = 0; i < pathPoints2D.length; i++) {
            var p = pathPoints2D[i];
            pathPoints3D.push(new THREE.Vector3(p.x, 0.0, p.y));
        }
        stone.userData.mode = "path";
        stone.userData.pathPoints = pathPoints3D;
        stone.userData.pathIndex = 0;
        stone.userData.moving = true;
        stone.userData.velocity.set(0, 0, 0);
    }

    currentThrow++;

    var scoresZero = computeScoreForStones(stones, houseCenter);
    updateScoreDisplay(scoresZero, currentThrow, maxThrows);

    if (team === "rouge") {
        activeBroom = broomRed;
    } else {
        activeBroom = broomBlue;
    }
    activeBroomStone = stone;
    broomPhase = 0;
}

function resetScene() {
    currentThrow = 0;

    var redIndex = 0;
    var blueIndex = 0;

    for (var i = 0; i < stones.length; i++) {
        var s = stones[i];
        if (s.userData.team === "rouge") {
            s.position.set(-1.5, 0.0, -5.6 - redIndex * 0.35);
            redIndex++;
        } else if (s.userData.team === "bleu") {
            s.position.set(1.5, 0.0, -5.6 - blueIndex * 0.35);
            blueIndex++;
        }
        s.userData.velocity.set(0, 0, 0);
        s.userData.moving = false;
        s.userData.mode = "waiting";
        s.userData.pathPoints = null;
        s.userData.pathIndex = 0;
        s.userData.inGame = false;
    }

    // Réinitialiser les balais à leur position de repos (coins)
    setBroomToHome(broomRed);
    setBroomToHome(broomBlue);
    activeBroom = null;
    activeBroomStone = null;

    updateScoreDisplay({ rouge: 0, bleu: 0 }, currentThrow, maxThrows);
}

function isAnyStoneMoving() {
    for (var i = 0; i < stones.length; i++) {
        if (stones[i].userData.moving) {
            return true;
        }
    }
    return false;
}

function updateBroom(delta) {
    if (!activeBroom) return;

    var broom = activeBroom;

    // Si le balai est en train de retourner à sa position de repos
    if (broom.userData.returning) {
        var dur = broom.userData.returnDuration || 0.6;
        var t = (broom.userData.returnT || 0) + delta / dur;
        if (t > 1) t = 1;
        broom.userData.returnT = t;

        var startPos = broom.userData.returnStartPos;
        var homePos = broom.userData.homePos;
        if (startPos && homePos) {
            broom.position.lerpVectors(startPos, homePos, t);
        }
        if (broom.userData.baseTiltX !== undefined) {
            broom.rotation.x = broom.userData.baseTiltX;
        }
        if (broom.userData.returnStartRotY !== undefined && broom.userData.homeRotY !== undefined) {
            broom.rotation.y = broom.userData.returnStartRotY +
                (broom.userData.homeRotY - broom.userData.returnStartRotY) * t;
        }

        if (t >= 1) {
            broom.userData.returning = false;
            setBroomToHome(broom);
            activeBroom = null;
        }
        return;
    }

    if (!activeBroomStone) return;

    var s = activeBroomStone;

    // Si la pierre ne bouge plus, lancer le retour animé du balai vers son coin
    if (!s.userData.moving) {
        startBroomReturn(broom);
        activeBroomStone = null;
        return;
    }

    var v = s.userData.velocity.clone();
    v.y = 0;
    var dir = new THREE.Vector3(0, 0, 1);
    if (v.length() > 0.01) {
        dir.copy(v).normalize();
        broom.userData.lastDir.copy(dir);
    } else {
        dir.copy(broom.userData.lastDir);
    }

    var offsetDist = STONE_RADIUS * 1.4;
    var offset = dir.clone().multiplyScalar(offsetDist);

    broom.position.x = s.position.x + offset.x;
    broom.position.z = s.position.z + offset.z;
    broom.position.y = 0.05;

    var angle = Math.atan2(dir.x, dir.z) + Math.PI * 0.5;
    broom.rotation.y = angle;

    broomPhase += delta * 15.0;
    var shake = Math.sin(broomPhase) * 0.18;
    broom.rotation.x = broom.userData.baseTiltX + shake;

    var perp = new THREE.Vector3(-dir.z, 0, dir.x);
    var lateralAmp = Math.sin(broomPhase * 2.0) * 0.04;
    broom.position.x += perp.x * lateralAmp;
    broom.position.z += perp.z * lateralAmp;

    // Disparaître (retour au coin) quelques "centimètres" avant une autre pierre
    var threshold = STONE_RADIUS * 2.2; // un peu plus d'écart
    for (var i = 0; i < stones.length; i++) {
        var tStone = stones[i];
        if (tStone === s) continue;
        var dx = tStone.position.x - broom.position.x;
        var dz = tStone.position.z - broom.position.z;
        var dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < threshold) {
            startBroomReturn(broom);
            activeBroomStone = null;
            return;
        }
    }
}


function updateStones(delta) {
    anyStoneMoving = false;

    for (var i = 0; i < stones.length; i++) {
        var s = stones[i];
        if (!s.userData) continue;

        if (s.userData.mode === "path" && s.userData.moving && s.userData.pathPoints) {
            var pts = s.userData.pathPoints;
            if (pts.length > 1) {
                var speedFactor = 30 + guiParams.puissance * 5;
                s.userData.pathIndex += speedFactor * delta;
                if (s.userData.pathIndex >= pts.length - 1) {
                    s.userData.pathIndex = pts.length - 1;
                    s.userData.moving = false;
                    s.userData.mode = "free";
                    s.userData.velocity.set(0, 0, 0);
                } else {
                    var idx = Math.floor(s.userData.pathIndex);
                    var nextIdx = Math.min(idx + 1, pts.length - 1);
                    var p = pts[idx];
                    var pNext = pts[nextIdx];

                    s.position.copy(p);

                    var dir = new THREE.Vector3().subVectors(pNext, p);
                    if (dir.length() > 0) {
                        dir.normalize();
                        var collisionSpeed = 1.2 + guiParams.puissance * 0.45;
                        s.userData.velocity.copy(dir.multiplyScalar(collisionSpeed));
                    }
                    s.rotation.y += 2.0 * delta;
                    s.userData.moving = true;
                }
            }
        } else if (s.userData.mode === "free" && s.userData.moving) {
            var v = s.userData.velocity;
            var speed = v.length();
            if (speed <= 0.001) {
                s.userData.velocity.set(0, 0, 0);
                s.userData.moving = false;
            } else {
                var friction = 0.8;
                var newSpeed = speed - friction * delta;
                if (newSpeed < 0) newSpeed = 0;
                if (speed > 0) {
                    v.multiplyScalar(newSpeed / speed);
                }
                s.position.x += v.x * delta;
                s.position.z += v.z * delta;
                s.rotation.y += newSpeed * 0.1 * delta;
            }
        }

        // Contraintes de la piste : on garde toujours les pierres dans la zone blanche
        var maxX = iceWidth * 0.5 - STONE_RADIUS;
        if (s.position.x < -maxX) s.position.x = -maxX;
        if (s.position.x > maxX) s.position.x = maxX;

        var minZ = -iceLength * 0.5 - STONE_RADIUS;
        var maxZ = iceLength * 0.5 - STONE_RADIUS;
        if (s.position.z < minZ) s.position.z = minZ;
        if (s.position.z > maxZ) s.position.z = maxZ;

        if (s.userData.moving) {
            anyStoneMoving = true;
        }
    }

    handleStoneCollisions(stones);

    for (var i = 0; i < stones.length; i++) {
        if (stones[i].userData.moving) {
            anyStoneMoving = true;
            break;
        }
    }

    updateBroom(delta);

    if (!anyStoneMoving && currentThrow > 0) {
        var scores = computeScoreForStones(stones, houseCenter);
        updateScoreDisplay(scores, currentThrow, maxThrows);
    }
}

function animate() {
    requestAnimationFrame(animate);
    var delta = clock.getDelta();
    updateStones(delta);
    renderer.render(scene, camera);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}
